--
-- Database: `herbonomics`
--
CREATE DATABASE IF NOT EXISTS `herbonomics` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `herbonomics`;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries`
--

CREATE TABLE `dispensaries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_demands`
--

CREATE TABLE `dispensaries_demands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dispensary_id` int(11) DEFAULT NULL,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_growers`
--

CREATE TABLE `dispensaries_growers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dispensary_id` int(11) DEFAULT NULL,
  `grower_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `growers`
--

CREATE TABLE `growers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `growers_strains`
--

CREATE TABLE `growers_strains` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `thc` int(11) DEFAULT NULL,
  `cbd` int(11) DEFAULT NULL,
  `cgc` tinyint(4) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `growers_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dispensaries`
--
ALTER TABLE `dispensaries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `dispensaries_demands`
--
ALTER TABLE `dispensaries_demands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `dispensaries_growers`
--
ALTER TABLE `dispensaries_growers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `growers`
--
ALTER TABLE `growers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `growers_strains`
--
ALTER TABLE `growers_strains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dispensaries`
--
ALTER TABLE `dispensaries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dispensaries_demands`
--
ALTER TABLE `dispensaries_demands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dispensaries_growers`
--
ALTER TABLE `dispensaries_growers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `growers`
--
ALTER TABLE `growers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `growers_strains`
--
ALTER TABLE `growers_strains`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
