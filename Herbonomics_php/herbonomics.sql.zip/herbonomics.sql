-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2016 at 02:02 PM
-- Server version: 5.5.47-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `herbonomics`
--
CREATE DATABASE IF NOT EXISTS `herbonomics` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `herbonomics`;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries`
--

CREATE TABLE IF NOT EXISTS `dispensaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_demands`
--

CREATE TABLE IF NOT EXISTS `dispensaries_demands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dispensary_id` int(11) DEFAULT NULL,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_growers`
--

CREATE TABLE IF NOT EXISTS `dispensaries_growers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dispensary_id` int(11) DEFAULT NULL,
  `grower_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `growers`
--

CREATE TABLE IF NOT EXISTS `growers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `growers_strains`
--

CREATE TABLE IF NOT EXISTS `growers_strains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `thc` float(5,2) DEFAULT NULL,
  `cbd` float(5,2) DEFAULT NULL,
  `cgc` tinyint(4) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `growers_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
